import { useState, useEffect } from 'react';
import { request } from '../utils/api';

// ── Risk level config ─────────────────────────────────────────────────────────
const RISK = {
  HIGH:   { bg: '#fef2f2', text: '#991b1b', dot: '#dc2626', label: 'High'   },
  MEDIUM: { bg: '#fffbeb', text: '#92400e', dot: '#d97706', label: 'Medium' },
  LOW:    { bg: '#f0fdf4', text: '#14532d', dot: '#16a34a', label: 'Low'    },
};

// ── Category color map ────────────────────────────────────────────────────────
const CAT_COLOR = {
  PAYMENTS:       '#1d4ed8', LENDING:        '#15803d', AP_AR:         '#b45309',
  TREASURY:       '#0f766e', FRAUD:          '#dc2626', COMPLIANCE:    '#7c3aed',
  PROCUREMENT:    '#c2410c', INVESTMENTS:    '#0369a1', CUSTOMER_OPS:  '#0e7490',
  RECONCILIATION: '#1e40af', BILLING:        '#6d28d9', INSURANCE:     '#065f46',
  REPORTING:      '#374151', RISK_MANAGEMENT:'#9f1239',
};

const catColor = (cat) => CAT_COLOR[cat] ?? '#475569';

// ── Intent card ───────────────────────────────────────────────────────────────
function IntentCard({ intent }) {
  const risk  = RISK[intent.riskLevel] ?? RISK.MEDIUM;
  const col   = catColor(intent.category);
  const name  = intent.name.replace(/_/g, ' ');

  return (
    <div style={{
      background: 'var(--color-background-primary)',
      border: '0.5px solid var(--color-border-tertiary)',
      borderRadius: 'var(--border-radius-lg)',
      borderLeft: `3px solid ${col}`,
      padding: '12px 14px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      transition: 'border-color 0.15s',
    }}
    onMouseEnter={e => e.currentTarget.style.borderColor = col}
    onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--color-border-tertiary)'}
    >
      {/* Name + active badge */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <p style={{ margin: 0, fontSize: 13, fontWeight: 500,
          color: 'var(--color-text-primary)', lineHeight: 1.4,
          textTransform: 'capitalize', letterSpacing: '0.01em' }}>
          {name}
        </p>
        {intent.isActive === false && (
          <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4,
            background: 'var(--color-background-secondary)',
            color: 'var(--color-text-tertiary)', whiteSpace: 'nowrap', flexShrink: 0 }}>
            inactive
          </span>
        )}
      </div>

      {/* Description */}
      {intent.description && (
        <p style={{ margin: 0, fontSize: 11.5, color: 'var(--color-text-secondary)',
          lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {intent.description}
        </p>
      )}

      {/* Meta row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap', marginTop: 2 }}>
        {/* Risk */}
        <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11,
          padding: '2px 7px', borderRadius: 20,
          background: risk.bg, color: risk.text }}>
          <span style={{ width: 5, height: 5, borderRadius: '50%',
            background: risk.dot, display: 'inline-block' }} />
          {risk.label}
        </span>

        {/* Policy */}
        {intent.defaultPolicy && (
          <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 20,
            background: 'var(--color-background-secondary)',
            color: 'var(--color-text-secondary)', textTransform: 'capitalize' }}>
            {intent.defaultPolicy.replace(/_/g, ' ')}
          </span>
        )}

        {/* SLA */}
        {intent.slaMs != null && (
          <span style={{ fontSize: 11, padding: '2px 7px', borderRadius: 20,
            background: 'var(--color-background-secondary)',
            color: 'var(--color-text-secondary)', marginLeft: 'auto' }}>
            {intent.slaMs} ms
          </span>
        )}
      </div>
    </div>
  );
}

// ── Category badge ────────────────────────────────────────────────────────────
function CategoryBadge({ name, count, selected, onClick }) {
  const col = catColor(name);
  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '5px 10px 5px 8px',
        border: selected ? `1.5px solid ${col}` : '0.5px solid var(--color-border-tertiary)',
        borderRadius: 20, cursor: 'pointer', transition: 'all 0.15s',
        background: selected ? col + '14' : 'var(--color-background-primary)',
        color: selected ? col : 'var(--color-text-secondary)',
        fontSize: 12, fontWeight: selected ? 500 : 400, whiteSpace: 'nowrap',
      }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%',
        background: col, display: 'inline-block', flexShrink: 0 }} />
      {name.replace(/_/g, ' ')}
      <span style={{
        fontSize: 10, padding: '1px 5px', borderRadius: 10,
        background: selected ? col : 'var(--color-background-secondary)',
        color: selected ? '#fff' : 'var(--color-text-tertiary)', lineHeight: 1.6,
      }}>{count}</span>
    </button>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function FintechIntents({ keycloak }) {
  const [categories,   setCategories]   = useState([]);
  const [selected,     setSelected]     = useState(null);
  const [intents,      setIntents]      = useState([]);
  const [catCounts,    setCatCounts]    = useState({});
  const [loadingCats,  setLoadingCats]  = useState(true);
  const [loadingItems, setLoadingItems] = useState(false);
  const [search,       setSearch]       = useState('');
  const [riskFilter,   setRiskFilter]   = useState('ALL');
  const [error,        setError]        = useState(null);

  // ── Load categories + counts on mount ──────────────────────────────────────
  useEffect(() => {
    setLoadingCats(true);
    Promise.all([
      request(keycloak, '/intents/categories'),
      request(keycloak, '/intents'),
    ])
      .then(([cats, all]) => {
        setCategories(cats ?? []);
        // Build count map from all intents
        const counts = {};
        (all ?? []).forEach(i => { counts[i.category] = (counts[i.category] ?? 0) + 1; });
        setCatCounts(counts);
        if (cats?.length) setSelected(cats[0]);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoadingCats(false));
  }, []);

  // ── Load intents when category changes ─────────────────────────────────────
  useEffect(() => {
    if (!selected) return;
    setLoadingItems(true);
    setSearch('');
    setRiskFilter('ALL');
    request(keycloak, `/intents/category/${selected}`)
      .then(data => setIntents(data ?? []))
      .catch(err => setError(err.message))
      .finally(() => setLoadingItems(false));
  }, [selected]);

  // ── Filtered intents ────────────────────────────────────────────────────────
  const filtered = intents.filter(i => {
    const matchSearch = !search || i.name.toLowerCase().includes(search.toLowerCase())
      || i.description?.toLowerCase().includes(search.toLowerCase());
    const matchRisk = riskFilter === 'ALL' || i.riskLevel === riskFilter;
    return matchSearch && matchRisk;
  });

  const col = selected ? catColor(selected) : '#475569';
  const totalIntents = Object.values(catCounts).reduce((a, b) => a + b, 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0,
      fontFamily: 'var(--font-sans)' }}>

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'flex-start',
        justifyContent: 'space-between', flexWrap: 'wrap', gap: 12,
        marginBottom: 20 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 20, fontWeight: 500,
            color: 'var(--color-text-primary)', letterSpacing: '-0.02em' }}>
            Fintech intent library
          </h1>
          <p style={{ margin: '4px 0 0', fontSize: 13,
            color: 'var(--color-text-secondary)' }}>
            {loadingCats ? '—' : `${totalIntents} intents across ${categories.length} categories`}
          </p>
        </div>

        {/* Risk filter */}
        <div style={{ display: 'flex', gap: 6 }}>
          {['ALL', 'HIGH', 'MEDIUM', 'LOW'].map(r => (
            <button key={r} onClick={() => setRiskFilter(r)} style={{
              fontSize: 11, padding: '4px 10px', borderRadius: 20, cursor: 'pointer',
              border: riskFilter === r
                ? `1.5px solid ${r === 'HIGH' ? '#dc2626' : r === 'MEDIUM' ? '#d97706' : r === 'LOW' ? '#16a34a' : 'var(--color-border-primary)'}`
                : '0.5px solid var(--color-border-tertiary)',
              background: riskFilter === r ? 'var(--color-background-secondary)' : 'transparent',
              color: riskFilter === r
                ? r === 'HIGH' ? '#dc2626' : r === 'MEDIUM' ? '#d97706' : r === 'LOW' ? '#16a34a' : 'var(--color-text-primary)'
                : 'var(--color-text-secondary)',
              fontWeight: riskFilter === r ? 500 : 400,
            }}>{r === 'ALL' ? 'All risks' : r.charAt(0) + r.slice(1).toLowerCase()}</button>
          ))}
        </div>
      </div>

      {error && (
        <div style={{ padding: '10px 14px', borderRadius: 'var(--border-radius-md)',
          background: 'var(--color-background-danger)',
          color: 'var(--color-text-danger)', fontSize: 13, marginBottom: 16 }}>
          {error}
        </div>
      )}

      {/* ── Category pills scrollable row ──────────────────────────────────── */}
      <div style={{
        display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 8,
        scrollbarWidth: 'none', marginBottom: 16,
        borderBottom: '0.5px solid var(--color-border-tertiary)',
        paddingTop: 2,
      }}>
        {loadingCats
          ? Array.from({ length: 6 }).map((_, i) => (
              <div key={i} style={{ height: 28, width: 90 + i * 12, borderRadius: 20,
                background: 'var(--color-background-secondary)', flexShrink: 0 }} />
            ))
          : categories.map(cat => (
              <CategoryBadge
                key={cat}
                name={cat}
                count={catCounts[cat] ?? 0}
                selected={selected === cat}
                onClick={() => setSelected(cat)}
              />
            ))
        }
      </div>

      {/* ── Active category header + search ────────────────────────────────── */}
      {selected && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10,
          marginBottom: 14, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 200 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%',
              background: col, flexShrink: 0 }} />
            <span style={{ fontSize: 14, fontWeight: 500,
              color: 'var(--color-text-primary)' }}>
              {selected.replace(/_/g, ' ')}
            </span>
            <span style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>
              {loadingItems ? '…' : `${filtered.length} of ${intents.length}`}
            </span>
          </div>

          {/* Search */}
          <div style={{ position: 'relative', flexShrink: 0 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
              stroke="var(--color-text-tertiary)" strokeWidth="2"
              style={{ position: 'absolute', left: 9, top: '50%',
                transform: 'translateY(-50%)', pointerEvents: 'none' }}>
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              type="text"
              placeholder="Search intents…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ paddingLeft: 28, width: 200, fontSize: 13 }}
            />
          </div>
        </div>
      )}

      {/* ── Intent grid ────────────────────────────────────────────────────── */}
      {loadingItems ? (
        <div style={{ display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} style={{ height: 100, borderRadius: 'var(--border-radius-lg)',
              background: 'var(--color-background-secondary)',
              animation: 'pulse 1.5s ease-in-out infinite' }} />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px 0',
          color: 'var(--color-text-tertiary)', fontSize: 14 }}>
          {search ? `No intents matching "${search}"` : 'No intents in this category'}
        </div>
      ) : (
        <div style={{ display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
          {filtered.map(intent => (
            <IntentCard key={intent.id} intent={intent} />
          ))}
        </div>
      )}

      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }`}</style>
    </div>
  );
}
