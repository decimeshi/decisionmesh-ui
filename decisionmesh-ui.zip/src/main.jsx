import React, { useMemo, useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { AuthProvider, useAuth } from 'react-oidc-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import { ProjectProvider }  from './context/ProjectContext';
import { BrandingProvider } from './context/BrandingContext';
import { CreditProvider }   from './context/CreditContext';
import App          from './App';
import LandingPage  from './pages/LandingPage';
import Onboarding   from './pages/Onboarding';
import { getMe }    from './utils/api';
import { oidcConfig, createKeycloakShim } from './auth/zitadel';
import './index.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: (count, err) => {
        const status = err?.response?.status;
        if (status >= 400 && status < 500) return false;
        return count < 2;
      },
    },
  },
});

function FullScreenSpinner() {
  return (
    <div style={{
      height: '100vh', display: 'flex', alignItems: 'center',
      justifyContent: 'center', background: '#f8fafc',
    }}>
      <div style={{
        width: 32, height: 32,
        border: '2px solid rgba(37,99,235,0.3)',
        borderTopColor: '#2563eb',
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function AppWrapper() {
  const auth = useAuth();

  const [provisioned,  setProvisioned]  = useState(false);
  const [needsOnboard, setNeedsOnboard] = useState(false);

  // ── Build Keycloak-compatible shim ─────────────────────────────────────────
  // All existing code (api.js, BrandingContext, pages) uses keycloak.token —
  // the shim wraps oidc-client-ts User into the same interface.
  // No changes needed anywhere else in the codebase.
  const keycloak = useMemo(
    () => createKeycloakShim(auth.user, auth),
    [auth.user, auth.isAuthenticated]
  );

  // ── Provision user on login — same flow as before ──────────────────────────
  useEffect(() => {
    if (!auth.isAuthenticated || !auth.user?.access_token) return;

    getMe(keycloak)
      .then(meData => {
        const onboarded = meData?.onboarded === true;
        setNeedsOnboard(!onboarded);
        setProvisioned(true);
      })
      .catch(() => {
        // /me failed — allow app to load, pages handle individual errors
        setNeedsOnboard(false);
        setProvisioned(true);
      });

  }, [auth.isAuthenticated, auth.user?.access_token]);

  // ── Render ─────────────────────────────────────────────────────────────────
  if (auth.isLoading)        return <FullScreenSpinner />;
  if (auth.error)            return <LandingPage />;
  if (!auth.isAuthenticated) return <LandingPage />;
  if (!provisioned)          return <FullScreenSpinner />;
  if (needsOnboard)          return <Onboarding keycloak={keycloak} />;

  return (
    <BrandingProvider keycloak={keycloak}>
      <ProjectProvider keycloak={keycloak}>
        <CreditProvider keycloak={keycloak}>
          <App keycloak={keycloak} />
        </CreditProvider>
      </ProjectProvider>
    </BrandingProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <AuthProvider
    {...oidcConfig}
    onSigninCallback={() => window.history.replaceState({}, '', '/')}
    onSilentRenewError={(err) => {
      // Suppress silent renew errors — don't let them trigger logout
      console.warn('[OIDC] Silent renew suppressed:', err?.message);
    }}
    onRemoveUser={() => {
      // Don't auto-redirect on session expiry — let user stay on page
      console.warn('[OIDC] Session removed — user stays on current page');
    }}
  >
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AppWrapper />
      </BrowserRouter>
    </QueryClientProvider>
  </AuthProvider>
);
