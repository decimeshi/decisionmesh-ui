// src/auth/zitadel.js
//
// Configures oidc-client-ts for Zitadel Cloud (PKCE, no client secret).
//
// .env.development:
//   VITE_ZITADEL_AUTHORITY=https://decisionmesh-1pgrry.eu1.zitadel.cloud
//   VITE_ZITADEL_CLIENT_ID=368134611768783581
//   VITE_ZITADEL_REDIRECT_URI=http://localhost:3000/auth/callback
//   VITE_ZITADEL_POST_LOGOUT_URI=http://localhost:3000

import { WebStorageStateStore } from 'oidc-client-ts';

const AUTHORITY   = import.meta.env.VITE_ZITADEL_AUTHORITY
    ?? 'https://decisionmesh-1pgrry.eu1.zitadel.cloud';

const CLIENT_ID   = import.meta.env.VITE_ZITADEL_CLIENT_ID
    ?? '368134611768783581';

const REDIRECT_URI = import.meta.env.VITE_ZITADEL_REDIRECT_URI
    ?? 'http://localhost:3000/auth/callback';

const POST_LOGOUT = import.meta.env.VITE_ZITADEL_POST_LOGOUT_URI
    ?? 'http://localhost:3000';

// ── OIDC config ───────────────────────────────────────────────────────────────
export const oidcConfig = {
    authority:                AUTHORITY,
    client_id:                CLIENT_ID,
    redirect_uri:             REDIRECT_URI,
    post_logout_redirect_uri: POST_LOGOUT,
    response_type:            'code',
    scope:                    'openid profile email',

    automaticSilentRenew:        false,   // ← no background renewal
    monitorSession:              false,   // ← no iframe session check
    checkSessionInterval:        0,       // ← no polling
    includeIdTokenInSilentRenew: false,
    filterProtocolClaims:        true,

    userStore: new WebStorageStateStore({ store: window.sessionStorage }),
    loadUserInfo: true,
};


// ── Keycloak-compatible shim ──────────────────────────────────────────────────
// Wraps react-oidc-context auth into a keycloak-like interface.
// All existing code (api.js, BrandingContext, pages) works without changes.
export function createKeycloakShim(user, auth) {
    if (!user) {
        return {
            authenticated: false,
            token:         null,
            tokenParsed:   null,
            login:         () => auth.signinRedirect(),
            logout:        () => auth.signoutRedirect(),
            updateToken:   () => Promise.resolve(false),
        };
    }

    return {
        authenticated: true,
        token:         user.access_token,
        tokenParsed:   user.profile,
        login:         () => auth.signinRedirect(),
        logout:        () => auth.signoutRedirect(),

        updateToken: (minValidity = 30) => {
            const exp   = user.expires_at ?? 0;
            const now   = Math.floor(Date.now() / 1000);
            const valid = exp - now > minValidity;

            if (valid) return Promise.resolve(true);

            // Attempt silent renewal — if it fails, keep existing token
            // rather than logging the user out
            return auth.signinSilent()
                .then(() => true)
                .catch((err) => {
                    console.warn('[Zitadel] Silent renew failed (non-fatal):', err?.message);
                    return false;  // ← keep existing token, don't logout
                });
        },
    };
}